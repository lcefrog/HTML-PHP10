// 1. Khai báo biến là tên đầy đủ của mình
document.write("1. Khai bao bien la ten day du cua minh: ");
document.write("var myName = 'Luong Hoai Canh'");
var myName = "Luong Hoai Canh";
// 2. Đếm số ký tự có trong tên của mình
document.write("<br>");
document.write("2. So ky tu trong ten cua minh la: ");
document.write(myName.length);
// 3. Kiểm tra xem chữ 'n' đầu tiên nằm ở vị trí thứ mấy trong tên của mình
document.write("<br>");
document.write("3. Chu n dau tien trong ten cua minh o vi tri so: ");
document.write(myName.indexOf('n'));
// 4. Kiểm tra chữ 'n' cuối cùng năm ở vị trí thứ mấy trong tên của mình
document.write("<br>");
document.write("4. Chu n cuoi cung trong ten cua minh o vi tri so: ");
document.write(myName.lastIndexOf('n'));
// 5. Đếm xem tên mình có mấy chữ
document.write("<br>");
document.write("5. Ten cua ban co bao nhieu tu: ");
document.write(myName.split(' ').length);
// Ví dụ: Lê Văn A là có 3 chữ
// 6. Thay thế họ của mình bằng chữ PHP10
document.write("<br>");
document.write("6. Thay the ho cua minh bang chu PHP10: ");
document.write(myName.replace('Luong', 'PHP10'));
// 7. In hoa tên của mình tên
document.write("<br>");
document.write("7. In hoa ten cua minh: ");
document.write(myName.toUpperCase());
// 8. In thường tên của mình lên
document.write("<br>");
document.write("8. In thuong ten cua minh: ");
document.write(myName.toLowerCase());